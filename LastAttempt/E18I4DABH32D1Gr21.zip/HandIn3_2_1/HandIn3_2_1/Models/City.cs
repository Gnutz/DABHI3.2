﻿using System;
using System.Collections.Generic;

namespace HandIn3_2_1.Models
{
    public partial class City
    {
        public long CityId { get; set; }
        public string CityName { get; set; }
        public string ZipCode { get; set; }
    }
}
